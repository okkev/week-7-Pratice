const chai = window.chai 
const expect = chai.expect

describe('getCel', () => {
    it('this should convert FtoC for all the values in the Array', ()=> {
        expect(getCel([23, 140, 212, 41]).to.deep.equal([-5, 60, 100, 5]))// what we are passing in 
    })
})